# 📘 Harbour Documentation

**Generated:** 10/09/2026
**Total symbols:** 59

## 📑 Table of Contents

- [TBaseEntity](#tbaseentity) `[class]`
- [New](#new) `[method]`
- [GetId](#getid) `[method]`
- [SetId](#setid) `[method]`
- [MarkDeleted](#markdeleted) `[method]`
- [IsActive](#isactive) `[method]`
- [ToHash](#tohash) `[method]`
- [Validate](#validate) `[method]`
- [New](#new) `[method]`
- [GetId](#getid) `[method]`
- [SetId](#setid) `[method]`
- [MarkDeleted](#markdeleted) `[method]`
- [IsActive](#isactive) `[method]`
- [ToHash](#tohash) `[method]`
- [Validate](#validate) `[method]`
- [TCustomer](#tcustomer) `[class]`
- [New](#new) `[method]`
- [GetDisplayName](#getdisplayname) `[method]`
- [AddToBalance](#addtobalance) `[method]`
- [Validate](#validate) `[method]`
- [ToHash](#tohash) `[method]`
- [New](#new) `[method]`
- [GetDisplayName](#getdisplayname) `[method]`
- [AddToBalance](#addtobalance) `[method]`
- [Validate](#validate) `[method]`
- [ToHash](#tohash) `[method]`
- [TOrder](#torder) `[class]`
- [New](#new) `[method]`
- [AddItem](#additem) `[method]`
- [CalculateTotals](#calculatetotals) `[method]`
- [GetStatus](#getstatus) `[method]`
- [SetStatus](#setstatus) `[method]`
- [ToHash](#tohash) `[method]`
- [New](#new) `[method]`
- [AddItem](#additem) `[method]`
- [CalculateTotals](#calculatetotals) `[method]`
- [GetStatus](#getstatus) `[method]`
- [SetStatus](#setstatus) `[method]`
- [ToHash](#tohash) `[method]`
- [CalculateTotal](#calculatetotal) `[function]`
- [FormatCurrency](#formatcurrency) `[function]`
- [GenerateUniqueId](#generateuniqueid) `[function]`
- [SafeNumber](#safenumber) `[function]`
- [SafeString](#safestring) `[function]`
- [BusinessDaysBetween](#businessdaysbetween) `[function]`
- [FormatDateRange](#formatdaterange) `[function]`
- [LogEvent](#logevent) `[function]`
- [MAX_NAME_LENGTH](#max_name_length) `[constant]`
- [MAX_EMAIL_LENGTH](#max_email_length) `[constant]`
- [MAX_ORDER_ITEMS](#max_order_items) `[constant]`
- [MIN_ITEM_QTY](#min_item_qty) `[constant]`
- [MAX_ITEM_QTY](#max_item_qty) `[constant]`
- [APP_VERSION](#app_version) `[constant]`
- [ValidateCustomerName](#validatecustomername) `[function]`
- [ValidateEmail](#validateemail) `[function]`
- [ValidateQuantity](#validatequantity) `[function]`
- [ValidateOrderItems](#validateorderitems) `[function]`
- [ValidatePhone](#validatephone) `[function]`
- [ShowValidationSummary](#showvalidationsummary) `[function]`

---

## TBaseEntity
**Type:** `class` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 33)

Base entity class providing common fields and behavior for all business model objects. Includes audit tracking, soft delete support, and hash serialization. All domain models should inherit from this class.

### 🔗 See Also
- [TCustomer](#tcustomer)
- [TOrder](#torder)

---

## New
**Type:** `method`
**Source:** `src\sample_models.prg` (line 42)

---

## GetId
**Type:** `method`
**Source:** `src\sample_models.prg` (line 43)

---

## SetId
**Type:** `method`
**Source:** `src\sample_models.prg` (line 44)

---

## MarkDeleted
**Type:** `method`
**Source:** `src\sample_models.prg` (line 45)

---

## IsActive
**Type:** `method`
**Source:** `src\sample_models.prg` (line 46)

---

## ToHash
**Type:** `method`
**Source:** `src\sample_models.prg` (line 47)

---

## Validate
**Type:** `method`
**Source:** `src\sample_models.prg` (line 48)

---

## New
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 57)

Constructor for TBaseEntity. Initializes all audit fields with creation timestamp and default values.

### ↩️ Returns
`O` - New TBaseEntity instance

---

## GetId
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 70)

Returns the unique identifier of the entity.

### ↩️ Returns
`C` - Entity ID string

### 🔗 See Also
- [SetId](#setid)

---

## SetId
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 81)

Sets the unique identifier of the entity and updates the modification timestamp.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cId` | `C` | New identifier value |

### ↩️ Returns
`O` - Self for method chaining

### 🔗 See Also
- [GetId](#getid)

---

## MarkDeleted
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 94)

Performs a soft delete on the entity by setting the IS_DELETED flag. Does not physically remove the record.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cUser` | `C` | Username performing the deletion |

### ↩️ Returns
`O` - Self for method chaining

### 🔗 See Also
- [IsActive](#isactive)

---

## IsActive
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 108)

Checks whether the entity is currently active and not soft-deleted.

### ↩️ Returns
`L` - .T. if entity is active

### 🔗 See Also
- [MarkDeleted](#markdeleted)

---

## ToHash
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 120)

Serializes the entity to a hash representation for JSON export, logging, or persistence.

### ↩️ Returns
`H` - Hash with all entity fields

### 💡 Examples
```harbour
hData := oEntity:ToHash()
cJson := hb_jsonEncode( hData )

```

---

## Validate
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 140)

Validates the entity state before persistence. Base implementation checks that ID is non-empty. Subclasses should override and extend this method.

### ↩️ Returns
`L` - .T. if entity passes validation

---

## TCustomer
**Type:** `class` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 151)

Customer model representing a business client. Inherits from TBaseEntity and adds customer-specific fields such as name, contact info, and credit balance.

### 🔗 See Also
- [TBaseEntity](#tbaseentity)
- [TOrder](#torder)

---

## New
**Type:** `method`
**Source:** `src\sample_models.prg` (line 158)

---

## GetDisplayName
**Type:** `method`
**Source:** `src\sample_models.prg` (line 159)

---

## AddToBalance
**Type:** `method`
**Source:** `src\sample_models.prg` (line 160)

---

## Validate
**Type:** `method`
**Source:** `src\sample_models.prg` (line 161)

---

## ToHash
**Type:** `method`
**Source:** `src\sample_models.prg` (line 162)

---

## New
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 175)

Constructor for TCustomer. Calls parent constructor and initializes customer-specific fields.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cName` | `C` | Customer full name or company name |
| `cEmail` | `C` | Primary contact email address |

### ↩️ Returns
`O` - New TCustomer instance

### 💡 Examples
```harbour
oCust := TCustomer():New( "Acme Corp", "billing@acme.com" )

```

---

## GetDisplayName
**Type:** `method` | **Since:** v1.5.0
**Source:** `src\sample_models.prg` (line 198)

Returns a formatted display name combining the customer name and city for use in UI labels and reports.

### ↩️ Returns
`C` - Formatted display string

### 🔗 See Also
- [GetId](#getid)

---

## AddToBalance
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 219)

Adds or subtracts an amount from the customer credit balance. Positive values increase balance, negative values decrease it. Records the reason for audit.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `nAmount` | `N` | Amount to add (positive) or subtract (negative) |
| `cReason` | `C` | Business reason for the adjustment |

### ↩️ Returns
`N` - New balance after adjustment

### 💡 Examples
```harbour
nNewBal := oCust:AddToBalance( -150.00, "Invoice #4521 payment" )

```

### 🔗 See Also
- [Validate](#validate)

---

## Validate
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 231)

Validates customer data before persistence. Extends base validation with email format and name checks.

### ↩️ Returns
`L` - .T. if customer data is valid

### 🔗 See Also
- [TBaseEntity](#tbaseentity)

---

## ToHash
**Type:** `method` | **Since:** v1.0.0
**Source:** `src\sample_models.prg` (line 254)

Extended serialization including customer fields. Merges parent hash with customer-specific data.

### ↩️ Returns
`H` - Complete hash with all fields

---

## TOrder
**Type:** `class` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 273)

Order model representing a sales transaction. Inherits from TBaseEntity and tracks order items, totals, status, and customer reference.

### 🔗 See Also
- [TBaseEntity](#tbaseentity)
- [TCustomer](#tcustomer)

---

## New
**Type:** `method`
**Source:** `src\sample_models.prg` (line 282)

---

## AddItem
**Type:** `method`
**Source:** `src\sample_models.prg` (line 283)

---

## CalculateTotals
**Type:** `method`
**Source:** `src\sample_models.prg` (line 284)

---

## GetStatus
**Type:** `method`
**Source:** `src\sample_models.prg` (line 285)

---

## SetStatus
**Type:** `method`
**Source:** `src\sample_models.prg` (line 286)

---

## ToHash
**Type:** `method`
**Source:** `src\sample_models.prg` (line 287)

---

## New
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 299)

Constructor for TOrder. Sets the customer reference and initializes the order date to today.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cCustomerId` | `C` | ID of the customer placing the order |

### ↩️ Returns
`O` - New TOrder instance

### 💡 Examples
```harbour
oOrder := TOrder():New( "CUST-001" )

```

---

## AddItem
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 324)

Adds a line item to the order. Each item includes product description, quantity, and unit price.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cProduct` | `C` | Product name or description |
| `nQty` | `N` | Quantity ordered (must be > 0) |
| `nPrice` | `N` | Unit price for this item |

### ↩️ Returns
`L` - .T. if item was added successfully

### 💡 Examples
```harbour
oOrder:AddItem( "Widget A", 10, 25.50 )
oOrder:AddItem( "Widget B", 5, 12.00 )

```

### 🔗 See Also
- [CalculateTotals](#calculatetotals)

---

## CalculateTotals
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 351)

Recalculates order subtotal, tax, and grand total based on current line items and the given tax rate.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `nTaxRate` | `N` | Tax percentage to apply (0-100) |

### ↩️ Returns
`N` - Grand total after tax calculation

### 💡 Examples
```harbour
nTotal := oOrder:CalculateTotals( 12.0 )
// Applies 12% tax to the subtotal

```

### 🔗 See Also
- [AddItem](#additem)

---

## GetStatus
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 375)

Returns the current order status.

### ↩️ Returns
`C` - Status string (PENDING, CONFIRMED, SHIPPED, CANCELLED)

### 🔗 See Also
- [SetStatus](#setstatus)

---

## SetStatus
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 388)

Updates the order status and records the change timestamp. Validates that the transition is allowed by business rules.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cNewStatus` | `C` | New status value to set |

### ↩️ Returns
`L` - .T. if status was updated successfully

### 💡 Examples
```harbour
oOrder:SetStatus( "CONFIRMED" )

```

### 🔗 See Also
- [GetStatus](#getstatus)

---

## ToHash
**Type:** `method` | **Since:** v2.0.0
**Source:** `src\sample_models.prg` (line 412)

Extended serialization including order fields and items.

### ↩️ Returns
`H` - Complete hash with all order data

---

## CalculateTotal
**Type:** `function` | **Since:** v1.0.0
**Source:** `src\sample_utils.prg` (line 38)

Calculates the total price including tax and discount. This function applies a percentage tax to the base price and then subtracts an optional discount amount.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `nPrice` | `N` | Base unit price before tax |
| `nQuantity` | `N` | Number of units to calculate |
| `nTaxRate` | `N` | Tax percentage to apply (0-100) |
| `nDiscount` | `N` | Flat discount amount to subtract |

### ↩️ Returns
`N` - Final total price after tax and discount

### 💡 Examples
```harbour
nTotal := CalculateTotal( 100.00, 5, 12.0, 50.00 )
// Result: 510.00 (500 + 60 tax - 50 discount)

```

### 🔗 See Also
- [FormatCurrency](#formatcurrency)

---

## FormatCurrency
**Type:** `function` | **Since:** v1.0.0
**Source:** `src\sample_utils.prg` (line 61)

Formats a numeric value as a currency string with thousands separators and two decimal places.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `nAmount` | `N` | The monetary amount to format |
| `cSymbol` | `C` | Currency symbol prefix (e.g., "$", "EUR") |

### ↩️ Returns
`C` - Formatted currency string

### 💡 Examples
```harbour
cResult := FormatCurrency( 1234567.89, "$" )
// Result: "$1,234,567.89"

```

### 🔗 See Also
- [CalculateTotal](#calculatetotal)

---

## GenerateUniqueId
**Type:** `function` | **Since:** v2.1.0
**Source:** `src\sample_utils.prg` (line 91)

Generates a unique identifier string combining a prefix, timestamp, and random characters. Suitable for record IDs, session tokens, and transaction references.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cPrefix` | `C` | Prefix label for the identifier |
| `nLength` | `N` | Total desired length of the ID |

### ↩️ Returns
`C` - Generated unique identifier string

### 💡 Examples
```harbour
cId := GenerateUniqueId( "ORD", 16 )
// Result: "ORD-20261009-A7X2"

```

### 🔗 See Also
- [ValidateIdFormat](#validateidformat)

---

## SafeNumber
**Type:** `function` | **Since:** v1.2.0
**Source:** `src\sample_utils.prg` (line 128)

Safely converts a string value to numeric, returning a default value if the conversion fails or the input is empty. Prevents runtime errors when parsing user input.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cValue` | `C` | String value to convert |
| `nDefault` | `N` | Default value if conversion fails |

### ↩️ Returns
`N` - Converted numeric value or default

### 💡 Examples
```harbour
nAge := SafeNumber( "25", 0 )      // Result: 25
nAge := SafeNumber( "abc", 0 )     // Result: 0
nAge := SafeNumber( "", 18 )       // Result: 18

```

### 🔗 See Also
- [SafeString](#safestring)

---

## SafeString
**Type:** `function` | **Since:** v1.2.0
**Source:** `src\sample_utils.prg` (line 159)

Safely retrieves a string value, trimming whitespace and returning a default if the value is NIL or non-character.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `xValue` | `X` | Value to convert to string |
| `cDefault` | `C` | Default string if conversion fails |

### ↩️ Returns
`C` - Cleaned string value or default

### 💡 Examples
```harbour
cName := SafeString( "  John  ", "" )   // Result: "John"
cName := SafeString( NIL, "Unknown" )   // Result: "Unknown"

```

### 🔗 See Also
- [SafeNumber](#safenumber)

---

## BusinessDaysBetween
**Type:** `function` | **Since:** v3.0.0
**Source:** `src\sample_utils.prg` (line 184)

Calculates the number of business days between two dates, excluding weekends (Saturday and Sunday).

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `dStart` | `D` | Start date (inclusive) |
| `dEnd` | `D` | End date (inclusive) |

### ↩️ Returns
`N` - Number of business days between the dates

### 💡 Examples
```harbour
nDays := BusinessDaysBetween( CToD( "2026-10-01" ), CToD( "2026-10-09" ) )
// Result: 7 (excludes Oct 3-4 weekend)

```

### 🔗 See Also
- [FormatDateRange](#formatdaterange)

---

## FormatDateRange
**Type:** `function` | **Since:** v3.0.0
**Source:** `src\sample_utils.prg` (line 212)

Formats a date range into a human-readable string. Handles same-day ranges, same-month ranges, and cross-month ranges with appropriate formatting.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `dStart` | `D` | Range start date |
| `dEnd` | `D` | Range end date |

### ↩️ Returns
`C` - Formatted date range string

### 💡 Examples
```harbour
cRange := FormatDateRange( CToD( "2026-10-01" ), CToD( "2026-10-09" ) )
// Result: "Oct 1 - 9, 2026"

```

### 🔗 See Also
- [BusinessDaysBetween](#businessdaysbetween)

---

## LogEvent
**Type:** `function` | **Since:** v1.0.0
**Source:** `src\sample_utils.prg` (line 236)

Logs a system event to the application event table. This is a procedure (no return value) that writes audit trail entries for compliance and debugging purposes.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cEventCode` | `C` | Event type code (INFO, WARN, ERROR) |
| `cModule` | `C` | Module name generating the event |
| `cMessage` | `C` | Descriptive event message |
| `cUser` | `C` | Username associated with the event |

### 💡 Examples
```harbour
LogEvent( "INFO", "ORDERS", "Order #1234 created", "admin" )

```

### 🔗 See Also
- [CalculateTotal](#calculatetotal)

---

## MAX_NAME_LENGTH
**Type:** `constant` | **Since:** v1.0.0
**Source:** `src\sample_validators.prg` (line 33)

Maximum allowed length for customer name fields. Values exceeding this limit are rejected during validation.

### 💎 Value
```harbour
"60"
```

### 🔗 See Also
- [ValidateCustomerName](#validatecustomername)

---

## MAX_EMAIL_LENGTH
**Type:** `constant` | **Since:** v1.0.0
**Source:** `src\sample_validators.prg` (line 41)

Maximum allowed length for email address fields. Compliant with RFC 5321 practical limits.

### 💎 Value
```harbour
"120"
```

### 🔗 See Also
- [ValidateEmail](#validateemail)

---

## MAX_ORDER_ITEMS
**Type:** `constant` | **Since:** v2.0.0
**Source:** `src\sample_validators.prg` (line 49)

Maximum number of line items allowed per order. Orders exceeding this limit must be split.

### 💎 Value
```harbour
"500"
```

### 🔗 See Also
- [ValidateOrderItems](#validateorderitems)

---

## MIN_ITEM_QTY
**Type:** `constant` | **Since:** v2.0.0
**Source:** `src\sample_validators.prg` (line 56)

Minimum quantity allowed for a single order line item.

### 💎 Value
```harbour
"1"
```

### 🔗 See Also
- [ValidateQuantity](#validatequantity)

---

## MAX_ITEM_QTY
**Type:** `constant` | **Since:** v2.0.0
**Source:** `src\sample_validators.prg` (line 64)

Maximum quantity allowed for a single order line item. Prevents data entry errors and inventory overflow.

### 💎 Value
```harbour
"99999"
```

### 🔗 See Also
- [ValidateQuantity](#validatequantity)

---

## APP_VERSION
**Type:** `constant` | **Since:** v1.0.0
**Source:** `src\sample_validators.prg` (line 70)

Application version string displayed in all output.

### 💎 Value
```harbour
"3.1.0"
```

---

## ValidateCustomerName
**Type:** `function` | **Since:** v1.0.0
**Source:** `src\sample_validators.prg` (line 89)

Validates a customer name against business rules. Checks for empty values, maximum length, and forbidden characters that could cause database or display issues.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cName` | `C` | Customer name to validate |

### ↩️ Returns
`L` - .T. if the name passes all validation rules

### 💡 Examples
```harbour
IF !ValidateCustomerName( "" )
MsgStop( "Name is required" )
ENDIF

```

### 🔗 See Also
- [ValidateEmail](#validateemail)

---

## ValidateEmail
**Type:** `function` | **Since:** v1.0.0
**Source:** `src\sample_validators.prg` (line 113)

Validates an email address format using basic pattern matching. Checks for presence of @ symbol, domain part, and length constraints.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cEmail` | `C` | Email address to validate |

### ↩️ Returns
`L` - .T. if the email format is valid

### 💡 Examples
```harbour
IF ValidateEmail( "user@example.com" )
// Valid email
ENDIF

```

### 🔗 See Also
- [ValidateCustomerName](#validatecustomername)

---

## ValidateQuantity
**Type:** `function` | **Since:** v2.0.0
**Source:** `src\sample_validators.prg` (line 151)

Validates an order quantity against configured minimum and maximum limits defined by MAX_ITEM_QTY and MIN_ITEM_QTY.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `nQty` | `N` | Quantity value to validate |

### ↩️ Returns
`L` - .T. if quantity is within allowed range

### 💡 Examples
```harbour
IF !ValidateQuantity( 0 )
MsgStop( "Quantity must be at least 1" )
ENDIF

```

### 🔗 See Also
- [ValidateOrderItems](#validateorderitems)

---

## ValidateOrderItems
**Type:** `function` | **Since:** v2.0.0
**Source:** `src\sample_validators.prg` (line 178)

Validates the total number of items in an order against the MAX_ORDER_ITEMS limit. Returns an error message via reference parameter if validation fails.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `nItemCount` | `N` | Number of items to validate |
| `cErrorMsg` | `C` | Reference to receive error description |

### ↩️ Returns
`L` - .T. if item count is within limits

### 💡 Examples
```harbour
LOCAL cErr := ""
IF !ValidateOrderItems( 600, @cErr )
MsgStop( cErr )
ENDIF

```

### 🔗 See Also
- [ValidateQuantity](#validatequantity)
- [MAX_ORDER_ITEMS](#max_order_items)

---

## ValidatePhone
**Type:** `function` | **Since:** v1.5.0
**Source:** `src\sample_validators.prg` (line 208)

Validates a phone number format. Accepts digits, spaces, dashes, parentheses, and leading + for international format.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cPhone` | `C` | Phone number string to validate |

### ↩️ Returns
`L` - .T. if the phone format is acceptable

### 💡 Examples
```harbour
IF ValidatePhone( "+1 (555) 123-4567" )
// Valid phone
ENDIF

```

### 🔗 See Also
- [ValidateEmail](#validateemail)

---

## ShowValidationSummary
**Type:** `function` | **Since:** v1.0.0
**Source:** `src\sample_validators.prg` (line 242)

Displays a formatted summary of all validation results to the console. This is a procedure with no return value, used for testing and debugging validation logic.

### 📋 Parameters
| Name | Type | Description |
|------|------|-------------|
| `cModuleName` | `C` | Name of the module being tested |
| `nTotalChecks` | `N` | Total number of checks performed |
| `nPassed` | `N` | Number of checks that passed |
| `nFailed` | `N` | Number of checks that failed |

### 💡 Examples
```harbour
ShowValidationSummary( "Customers", 25, 23, 2 )

```

---

