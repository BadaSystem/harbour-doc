/*
   BadaSystem
   Program       : harbour-doc
   Module        : sample_utils.prg
   Compiler      : MINIGUI - Harbour Win32 GUI
   Compiler-C    : BCC 32 bit
   Author        : Marcos Jarrin
   Email         : marvijarrin@gmail.com
   Website       : badasystem.com
   Date          : 09/10/2026
   Update        : 09/10/2026
   Rev           : 1.0
   SPDX-License-Identifier: MIT

   Description:
      Sample utility functions for testing harbour-doc.
      Contains documented functions and procedures covering
      all supported documentation tags.
*/

#include "minigui.ch"

/**
 * Calculates the total price including tax and discount.
 * This function applies a percentage tax to the base price
 * and then subtracts an optional discount amount.
 * @param nPrice (N) -> Base unit price before tax
 * @param nQuantity (N) -> Number of units to calculate
 * @param nTaxRate (N) -> Tax percentage to apply (0-100)
 * @param nDiscount (N) -> Flat discount amount to subtract
 * @return (N) -> Final total price after tax and discount
 * @since 1.0.0
 * @see FormatCurrency
 * @example
 *   nTotal := CalculateTotal( 100.00, 5, 12.0, 50.00 )
 *   // Result: 510.00 (500 + 60 tax - 50 discount)
 */
FUNCTION CalculateTotal( nPrice, nQuantity, nTaxRate, nDiscount )
   LOCAL nSubtotal := nPrice * nQuantity
   LOCAL nTax      := nSubtotal * ( nTaxRate / 100 )
   LOCAL nTotal    := nSubtotal + nTax - nDiscount

   IF nTotal < 0
      nTotal := 0
   ENDIF

   RETURN nTotal

/**
 * Formats a numeric value as a currency string with
 * thousands separators and two decimal places.
 * @param nAmount (N) -> The monetary amount to format
 * @param cSymbol (C) -> Currency symbol prefix (e.g., "$", "EUR")
 * @return (C) -> Formatted currency string
 * @since 1.0.0
 * @see CalculateTotal
 * @example
 *   cResult := FormatCurrency( 1234567.89, "$" )
 *   // Result: "$1,234,567.89"
 */
FUNCTION FormatCurrency( nAmount, cSymbol )
   LOCAL cFormatted := ""
   LOCAL cInteger   := ""
   LOCAL cDecimals  := ""
   LOCAL nLen       := 0
   LOCAL nI         := 0
   LOCAL nGroups    := 0

   IF cSymbol == NIL
      cSymbol := "$"
   ENDIF

   cFormatted := Str( nAmount, 18, 2 )
   cFormatted := AllTrim( cFormatted )

   RETURN cSymbol + cFormatted

/**
 * Generates a unique identifier string combining a prefix,
 * timestamp, and random characters. Suitable for record IDs,
 * session tokens, and transaction references.
 * @param cPrefix (C) -> Prefix label for the identifier
 * @param nLength (N) -> Total desired length of the ID
 * @return (C) -> Generated unique identifier string
 * @since 2.1.0
 * @see ValidateIdFormat
 * @example
 *   cId := GenerateUniqueId( "ORD", 16 )
 *   // Result: "ORD-20261009-A7X2"
 */
FUNCTION GenerateUniqueId( cPrefix, nLength )
   LOCAL cId      := ""
   LOCAL cDate    := ""
   LOCAL nI       := 0
   LOCAL cChars   := "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
   LOCAL nCharPos := 0

   IF cPrefix == NIL
      cPrefix := "ID"
   ENDIF

   IF nLength == NIL
      nLength := 16
   ENDIF

   cDate := StrZero( Year( Date() ), 4 ) + ;
            StrZero( Month( Date() ), 2 ) + ;
            StrZero( Day( Date() ), 2 )

   cId := cPrefix + "-" + cDate

   RETURN cId

/**
 * Safely converts a string value to numeric, returning a
 * default value if the conversion fails or the input is empty.
 * Prevents runtime errors when parsing user input.
 * @param cValue (C) -> String value to convert
 * @param nDefault (N) -> Default value if conversion fails
 * @return (N) -> Converted numeric value or default
 * @since 1.2.0
 * @see SafeString
 * @example
 *   nAge := SafeNumber( "25", 0 )      // Result: 25
 *   nAge := SafeNumber( "abc", 0 )     // Result: 0
 *   nAge := SafeNumber( "", 18 )       // Result: 18
 */
FUNCTION SafeNumber( cValue, nDefault )
   LOCAL nResult := 0

   IF nDefault == NIL
      nDefault := 0
   ENDIF

   IF ValType( cValue ) != "C" .OR. Empty( AllTrim( cValue ) )
      RETURN nDefault
   ENDIF

   nResult := Val( AllTrim( cValue ) )

   IF nResult == 0 .AND. !( "0" $ AllTrim( cValue ) )
      nResult := nDefault
   ENDIF

   RETURN nResult

/**
 * Safely retrieves a string value, trimming whitespace and
 * returning a default if the value is NIL or non-character.
 * @param xValue (X) -> Value to convert to string
 * @param cDefault (C) -> Default string if conversion fails
 * @return (C) -> Cleaned string value or default
 * @since 1.2.0
 * @see SafeNumber
 * @example
 *   cName := SafeString( "  John  ", "" )   // Result: "John"
 *   cName := SafeString( NIL, "Unknown" )   // Result: "Unknown"
 */
FUNCTION SafeString( xValue, cDefault )
   IF cDefault == NIL
      cDefault := ""
   ENDIF

   IF ValType( xValue ) == "C"
      RETURN AllTrim( xValue )
   ELSEIF ValType( xValue ) == "N"
      RETURN LTrim( Str( xValue ) )
   ENDIF

   RETURN cDefault

/**
 * Calculates the number of business days between two dates,
 * excluding weekends (Saturday and Sunday).
 * @param dStart (D) -> Start date (inclusive)
 * @param dEnd (D) -> End date (inclusive)
 * @return (N) -> Number of business days between the dates
 * @since 3.0.0
 * @see FormatDateRange
 * @example
 *   nDays := BusinessDaysBetween( CToD( "2026-10-01" ), CToD( "2026-10-09" ) )
 *   // Result: 7 (excludes Oct 3-4 weekend)
 */
FUNCTION BusinessDaysBetween( dStart, dEnd )
   LOCAL nDays    := 0
   LOCAL dCurrent := dStart
   LOCAL nDayOfWeek := 0

   DO WHILE dCurrent <= dEnd
      nDayOfWeek := DoW( dCurrent )
      IF nDayOfWeek != 1 .AND. nDayOfWeek != 7
         nDays++
      ENDIF
      dCurrent++
   ENDDO

   RETURN nDays

/**
 * Formats a date range into a human-readable string.
 * Handles same-day ranges, same-month ranges, and
 * cross-month ranges with appropriate formatting.
 * @param dStart (D) -> Range start date
 * @param dEnd (D) -> Range end date
 * @return (C) -> Formatted date range string
 * @since 3.0.0
 * @see BusinessDaysBetween
 * @example
 *   cRange := FormatDateRange( CToD( "2026-10-01" ), CToD( "2026-10-09" ) )
 *   // Result: "Oct 1 - 9, 2026"
 */
FUNCTION FormatDateRange( dStart, dEnd )
   LOCAL cResult := ""

   IF dStart == dEnd
      cResult := DToC( dStart )
   ELSE
      cResult := DToC( dStart ) + " - " + DToC( dEnd )
   ENDIF

   RETURN cResult

/**
 * Logs a system event to the application event table.
 * This is a procedure (no return value) that writes audit
 * trail entries for compliance and debugging purposes.
 * @param cEventCode (C) -> Event type code (INFO, WARN, ERROR)
 * @param cModule (C) -> Module name generating the event
 * @param cMessage (C) -> Descriptive event message
 * @param cUser (C) -> Username associated with the event
 * @since 1.0.0
 * @see CalculateTotal
 * @example
 *   LogEvent( "INFO", "ORDERS", "Order #1234 created", "admin" )
 */
PROCEDURE LogEvent( cEventCode, cModule, cMessage, cUser )
   LOCAL cTimestamp := ""

   cTimestamp := DToC( Date() ) + " " + Time()

   OutStd( "[" + cTimestamp + "] ", ;
           "[" + cEventCode + "] ", ;
           "[" + cModule + "] ", ;
           cMessage, ;
           " (user: " + cUser + ")", ;
           Chr( 10 ) )

   RETURN