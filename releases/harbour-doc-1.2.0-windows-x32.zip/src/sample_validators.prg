/*
   BadaSystem
   Program       : harbour-doc
   Module        : sample_validators.prg
   Compiler      : MINIGUI - Harbour Win32 GUI
   Compiler-C    : BCC 32 bit
   Author        : Marcos Jarrin
   Email         : marvijarrin@gmail.com
   Website       : badasystem.com
   Date          : 09/10/2026
   Update        : 09/10/2026
   Rev           : 1.0
   SPDX-License-Identifier: MIT

   Description:
      Sample validation module with constants for testing
      harbour-doc. Demonstrates #define documentation,
      validation functions, and cross-references.
*/

#include "minigui.ch"

// ─────────────────────────────────────────────────────────────────────────────
// Application Constants
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Maximum allowed length for customer name fields.
 * Values exceeding this limit are rejected during validation.
 * @since 1.0.0
 * @see ValidateCustomerName
 */
#define MAX_NAME_LENGTH      60

/**
 * Maximum allowed length for email address fields.
 * Compliant with RFC 5321 practical limits.
 * @since 1.0.0
 * @see ValidateEmail
 */
#define MAX_EMAIL_LENGTH     120

/**
 * Maximum number of line items allowed per order.
 * Orders exceeding this limit must be split.
 * @since 2.0.0
 * @see ValidateOrderItems
 */
#define MAX_ORDER_ITEMS      500

/**
 * Minimum quantity allowed for a single order line item.
 * @since 2.0.0
 * @see ValidateQuantity
 */
#define MIN_ITEM_QTY         1

/**
 * Maximum quantity allowed for a single order line item.
 * Prevents data entry errors and inventory overflow.
 * @since 2.0.0
 * @see ValidateQuantity
 */
#define MAX_ITEM_QTY         99999

/**
 * Application version string displayed in all output.
 * @since 1.0.0
 */
#define APP_VERSION          "3.1.0"

// ─────────────────────────────────────────────────────────────────────────────
// Validation Functions
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Validates a customer name against business rules.
 * Checks for empty values, maximum length, and forbidden
 * characters that could cause database or display issues.
 * @param cName (C) -> Customer name to validate
 * @return (L) -> .T. if the name passes all validation rules
 * @since 1.0.0
 * @see ValidateEmail
 * @example
 *   IF !ValidateCustomerName( "" )
 *      MsgStop( "Name is required" )
 *   ENDIF
 */
FUNCTION ValidateCustomerName( cName )
   LOCAL lValid := .T.

   IF ValType( cName ) != "C" .OR. Empty( AllTrim( cName ) )
      lValid := .F.
   ELSEIF Len( AllTrim( cName ) ) > MAX_NAME_LENGTH
      lValid := .F.
   ENDIF

   RETURN lValid

/**
 * Validates an email address format using basic pattern
 * matching. Checks for presence of @ symbol, domain part,
 * and length constraints.
 * @param cEmail (C) -> Email address to validate
 * @return (L) -> .T. if the email format is valid
 * @since 1.0.0
 * @see ValidateCustomerName
 * @example
 *   IF ValidateEmail( "user@example.com" )
 *      // Valid email
 *   ENDIF
 */
FUNCTION ValidateEmail( cEmail )
   LOCAL lValid  := .T.
   LOCAL nAtPos  := 0
   LOCAL nDotPos := 0

   IF ValType( cEmail ) != "C" .OR. Empty( AllTrim( cEmail ) )
      RETURN .F.
   ENDIF

   IF Len( cEmail ) > MAX_EMAIL_LENGTH
      RETURN .F.
   ENDIF

   nAtPos := At( "@", cEmail )

   IF nAtPos == 0 .OR. nAtPos == 1 .OR. nAtPos == Len( cEmail )
      lValid := .F.
   ELSE
      nDotPos := At( ".", SubStr( cEmail, nAtPos + 1 ) )
      IF nDotPos == 0
         lValid := .F.
      ENDIF
   ENDIF

   RETURN lValid

/**
 * Validates an order quantity against configured minimum
 * and maximum limits defined by MAX_ITEM_QTY and MIN_ITEM_QTY.
 * @param nQty (N) -> Quantity value to validate
 * @return (L) -> .T. if quantity is within allowed range
 * @since 2.0.0
 * @see ValidateOrderItems
 * @example
 *   IF !ValidateQuantity( 0 )
 *      MsgStop( "Quantity must be at least 1" )
 *   ENDIF
 */
FUNCTION ValidateQuantity( nQty )
   LOCAL lValid := .T.

   IF ValType( nQty ) != "N"
      lValid := .F.
   ELSEIF nQty < MIN_ITEM_QTY .OR. nQty > MAX_ITEM_QTY
      lValid := .F.
   ENDIF

   RETURN lValid

/**
 * Validates the total number of items in an order against
 * the MAX_ORDER_ITEMS limit. Returns an error message via
 * reference parameter if validation fails.
 * @param nItemCount (N) -> Number of items to validate
 * @param cErrorMsg (C) -> Reference to receive error description
 * @return (L) -> .T. if item count is within limits
 * @since 2.0.0
 * @see ValidateQuantity
 * @see MAX_ORDER_ITEMS
 * @example
 *   LOCAL cErr := ""
 *   IF !ValidateOrderItems( 600, @cErr )
 *      MsgStop( cErr )
 *   ENDIF
 */
FUNCTION ValidateOrderItems( nItemCount, cErrorMsg )
   LOCAL lValid := .T.

   IF cErrorMsg == NIL
      cErrorMsg := ""
   ENDIF

   IF ValType( nItemCount ) != "N" .OR. nItemCount < 0
      cErrorMsg := "Item count must be a non-negative number"
      lValid := .F.
   ELSEIF nItemCount > MAX_ORDER_ITEMS
      cErrorMsg := "Order exceeds maximum of " + ;
                   LTrim( Str( MAX_ORDER_ITEMS ) ) + " items"
      lValid := .F.
   ENDIF

   RETURN lValid

/**
 * Validates a phone number format. Accepts digits, spaces,
 * dashes, parentheses, and leading + for international format.
 * @param cPhone (C) -> Phone number string to validate
 * @return (L) -> .T. if the phone format is acceptable
 * @since 1.5.0
 * @see ValidateEmail
 * @example
 *   IF ValidatePhone( "+1 (555) 123-4567" )
 *      // Valid phone
 *   ENDIF
 */
FUNCTION ValidatePhone( cPhone )
   LOCAL lValid := .T.
   LOCAL cClean := ""
   LOCAL nI     := 0
   LOCAL cChar  := ""

   IF ValType( cPhone ) != "C" .OR. Empty( AllTrim( cPhone ) )
      RETURN .F.
   ENDIF

   cClean := AllTrim( cPhone )

   FOR nI := 1 TO Len( cClean )
      cChar := SubStr( cClean, nI, 1 )
      IF !( cChar $ "0123456789+-() " )
         lValid := .F.
         EXIT
      ENDIF
   NEXT

   RETURN lValid

/**
 * Displays a formatted summary of all validation results
 * to the console. This is a procedure with no return value,
 * used for testing and debugging validation logic.
 * @param cModuleName (C) -> Name of the module being tested
 * @param nTotalChecks (N) -> Total number of checks performed
 * @param nPassed (N) -> Number of checks that passed
 * @param nFailed (N) -> Number of checks that failed
 * @since 1.0.0
 * @example
 *   ShowValidationSummary( "Customers", 25, 23, 2 )
 */
PROCEDURE ShowValidationSummary( cModuleName, nTotalChecks, nPassed, nFailed )
   LOCAL nCoverage := 0

   IF nTotalChecks > 0
      nCoverage := Int( ( nPassed / nTotalChecks ) * 100 )
   ENDIF

   OutStd( Chr( 10 ) )
   OutStd( "============================================", Chr( 10 ) )
   OutStd( "  Validation Summary - " + cModuleName, Chr( 10 ) )
   OutStd( "============================================", Chr( 10 ) )
   OutStd( "  Total Checks:  " + LTrim( Str( nTotalChecks ) ), Chr( 10 ) )
   OutStd( "  Passed:        " + LTrim( Str( nPassed ) ), Chr( 10 ) )
   OutStd( "  Failed:        " + LTrim( Str( nFailed ) ), Chr( 10 ) )
   OutStd( "  Coverage:      " + LTrim( Str( nCoverage ) ) + "%", Chr( 10 ) )
   OutStd( "============================================", Chr( 10 ) )
   OutStd( Chr( 10 ) )

   RETURN