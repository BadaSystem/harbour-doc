/*
   BadaSystem
   Program       : harbour-doc
   Module        : sample_models.prg
   Compiler      : MINIGUI - Harbour Win32 GUI
   Compiler-C    : BCC 32 bit
   Author        : Marcos Jarrin
   Email         : marvijarrin@gmail.com
   Website       : badasystem.com
   Date          : 09/10/2026
   Update        : 09/10/2026
   Rev           : 1.0
   SPDX-License-Identifier: MIT

   Description:
      Sample OOP model classes for testing harbour-doc.
      Demonstrates class documentation, inheritance, and
      method documentation with all supported tags.
*/

#include "minigui.ch"
#include "hbclass.ch"

/**
 * Base entity class providing common fields and behavior
 * for all business model objects. Includes audit tracking,
 * soft delete support, and hash serialization.
 * All domain models should inherit from this class.
 * @since 1.0.0
 * @see TCustomer
 * @see TOrder
 */
CLASS TBaseEntity
   DATA cId        INIT ""
   DATA dCreatedAt INIT NIL
   DATA dUpdatedAt INIT NIL
   DATA cCreatedBy INIT ""
   DATA cUpdatedBy INIT ""
   DATA lIsActive  INIT .T.
   DATA lIsDeleted INIT .F.

   METHOD New() CONSTRUCTOR
   METHOD GetId()
   METHOD SetId( cId )
   METHOD MarkDeleted( cUser )
   METHOD IsActive()
   METHOD ToHash()
   METHOD Validate()
ENDCLASS

/**
 * Constructor for TBaseEntity. Initializes all audit
 * fields with creation timestamp and default values.
 * @return (O) -> New TBaseEntity instance
 * @since 1.0.0
 */
METHOD New() CLASS TBaseEntity
   ::dCreatedAt := Date()
   ::dUpdatedAt := Date()
   ::cCreatedBy := "SYSTEM"
   ::cUpdatedBy := "SYSTEM"
   RETURN Self

/**
 * Returns the unique identifier of the entity.
 * @return (C) -> Entity ID string
 * @since 1.0.0
 * @see SetId
 */
METHOD GetId() CLASS TBaseEntity
   RETURN ::cId

/**
 * Sets the unique identifier of the entity and updates
 * the modification timestamp.
 * @param cId (C) -> New identifier value
 * @return (O) -> Self for method chaining
 * @since 1.0.0
 * @see GetId
 */
METHOD SetId( cId ) CLASS TBaseEntity
   ::cId       := cId
   ::dUpdatedAt := Date()
   RETURN Self

/**
 * Performs a soft delete on the entity by setting the
 * IS_DELETED flag. Does not physically remove the record.
 * @param cUser (C) -> Username performing the deletion
 * @return (O) -> Self for method chaining
 * @since 1.0.0
 * @see IsActive
 */
METHOD MarkDeleted( cUser ) CLASS TBaseEntity
   ::lIsDeleted := .T.
   ::lIsActive  := .F.
   ::cUpdatedBy := cUser
   ::dUpdatedAt := Date()
   RETURN Self

/**
 * Checks whether the entity is currently active and
 * not soft-deleted.
 * @return (L) -> .T. if entity is active
 * @since 1.0.0
 * @see MarkDeleted
 */
METHOD IsActive() CLASS TBaseEntity
   RETURN ::lIsActive .AND. !::lIsDeleted

/**
 * Serializes the entity to a hash representation for
 * JSON export, logging, or persistence.
 * @return (H) -> Hash with all entity fields
 * @since 1.0.0
 * @example
 *   hData := oEntity:ToHash()
 *   cJson := hb_jsonEncode( hData )
 */
METHOD ToHash() CLASS TBaseEntity
   LOCAL hOut := { => }

   hOut[ "cId" ]        := ::cId
   hOut[ "dCreatedAt" ] := ::dCreatedAt
   hOut[ "dUpdatedAt" ] := ::dUpdatedAt
   hOut[ "cCreatedBy" ] := ::cCreatedBy
   hOut[ "cUpdatedBy" ] := ::cUpdatedBy
   hOut[ "lIsActive" ]  := ::lIsActive
   hOut[ "lIsDeleted" ] := ::lIsDeleted

   RETURN hOut

/**
 * Validates the entity state before persistence.
 * Base implementation checks that ID is non-empty.
 * Subclasses should override and extend this method.
 * @return (L) -> .T. if entity passes validation
 * @since 1.0.0
 */
METHOD Validate() CLASS TBaseEntity
   RETURN !Empty( ::cId )

/**
 * Customer model representing a business client.
 * Inherits from TBaseEntity and adds customer-specific
 * fields such as name, contact info, and credit balance.
 * @since 1.0.0
 * @see TBaseEntity
 * @see TOrder
 */
CLASS TCustomer FROM TBaseEntity
   DATA cName     INIT ""
   DATA cEmail    INIT ""
   DATA cPhone    INIT ""
   DATA cCity     INIT ""
   DATA nBalance  INIT 0

   METHOD New( cName, cEmail ) CONSTRUCTOR
   METHOD GetDisplayName()
   METHOD AddToBalance( nAmount, cReason )
   METHOD Validate()
   METHOD ToHash()
ENDCLASS

/**
 * Constructor for TCustomer. Calls parent constructor
 * and initializes customer-specific fields.
 * @param cName (C) -> Customer full name or company name
 * @param cEmail (C) -> Primary contact email address
 * @return (O) -> New TCustomer instance
 * @since 1.0.0
 * @example
 *   oCust := TCustomer():New( "Acme Corp", "billing@acme.com" )
 */
METHOD New( cName, cEmail ) CLASS TCustomer
   ::Super:New()

   IF cName == NIL
      cName := ""
   ENDIF

   IF cEmail == NIL
      cEmail := ""
   ENDIF

   ::cName  := cName
   ::cEmail := cEmail

   RETURN Self

/**
 * Returns a formatted display name combining the customer
 * name and city for use in UI labels and reports.
 * @return (C) -> Formatted display string
 * @since 1.5.0
 * @see GetId
 */
METHOD GetDisplayName() CLASS TCustomer
   LOCAL cDisplay := ::cName

   IF !Empty( ::cCity )
      cDisplay += " (" + ::cCity + ")"
   ENDIF

   RETURN cDisplay

/**
 * Adds or subtracts an amount from the customer credit
 * balance. Positive values increase balance, negative
 * values decrease it. Records the reason for audit.
 * @param nAmount (N) -> Amount to add (positive) or subtract (negative)
 * @param cReason (C) -> Business reason for the adjustment
 * @return (N) -> New balance after adjustment
 * @since 2.0.0
 * @see Validate
 * @example
 *   nNewBal := oCust:AddToBalance( -150.00, "Invoice #4521 payment" )
 */
METHOD AddToBalance( nAmount, cReason ) CLASS TCustomer
   ::nBalance  += nAmount
   ::dUpdatedAt := Date()
   RETURN ::nBalance

/**
 * Validates customer data before persistence. Extends
 * base validation with email format and name checks.
 * @return (L) -> .T. if customer data is valid
 * @since 1.0.0
 * @see TBaseEntity
 */
METHOD Validate() CLASS TCustomer
   LOCAL lValid := .T.

   IF !::Super:Validate()
      lValid := .F.
   ENDIF

   IF Empty( ::cName )
      lValid := .F.
   ENDIF

   IF !Empty( ::cEmail ) .AND. !( "@" $ ::cEmail )
      lValid := .F.
   ENDIF

   RETURN lValid

/**
 * Extended serialization including customer fields.
 * Merges parent hash with customer-specific data.
 * @return (H) -> Complete hash with all fields
 * @since 1.0.0
 */
METHOD ToHash() CLASS TCustomer
   LOCAL hOut := ::Super:ToHash()

   hOut[ "cName" ]    := ::cName
   hOut[ "cEmail" ]   := ::cEmail
   hOut[ "cPhone" ]   := ::cPhone
   hOut[ "cCity" ]    := ::cCity
   hOut[ "nBalance" ] := ::nBalance

   RETURN hOut

/**
 * Order model representing a sales transaction.
 * Inherits from TBaseEntity and tracks order items,
 * totals, status, and customer reference.
 * @since 2.0.0
 * @see TBaseEntity
 * @see TCustomer
 */
CLASS TOrder FROM TBaseEntity
   DATA cCustomerId  INIT ""
   DATA dOrderDate   INIT NIL
   DATA cStatus      INIT "PENDING"
   DATA nSubtotal    INIT 0
   DATA nTaxAmount   INIT 0
   DATA nTotal       INIT 0
   DATA aItems       INIT {}

   METHOD New( cCustomerId ) CONSTRUCTOR
   METHOD AddItem( cProduct, nQty, nPrice )
   METHOD CalculateTotals( nTaxRate )
   METHOD GetStatus()
   METHOD SetStatus( cNewStatus )
   METHOD ToHash()
ENDCLASS

/**
 * Constructor for TOrder. Sets the customer reference
 * and initializes the order date to today.
 * @param cCustomerId (C) -> ID of the customer placing the order
 * @return (O) -> New TOrder instance
 * @since 2.0.0
 * @example
 *   oOrder := TOrder():New( "CUST-001" )
 */
METHOD New( cCustomerId ) CLASS TOrder
   ::Super:New()

   IF cCustomerId == NIL
      cCustomerId := ""
   ENDIF

   ::cCustomerId := cCustomerId
   ::dOrderDate  := Date()

   RETURN Self

/**
 * Adds a line item to the order. Each item includes
 * product description, quantity, and unit price.
 * @param cProduct (C) -> Product name or description
 * @param nQty (N) -> Quantity ordered (must be > 0)
 * @param nPrice (N) -> Unit price for this item
 * @return (L) -> .T. if item was added successfully
 * @since 2.0.0
 * @see CalculateTotals
 * @example
 *   oOrder:AddItem( "Widget A", 10, 25.50 )
 *   oOrder:AddItem( "Widget B", 5, 12.00 )
 */
METHOD AddItem( cProduct, nQty, nPrice ) CLASS TOrder
   LOCAL hItem := { => }

   IF nQty <= 0 .OR. nPrice < 0
      RETURN .F.
   ENDIF

   hItem[ "cProduct" ] := cProduct
   hItem[ "nQty" ]     := nQty
   hItem[ "nPrice" ]   := nPrice
   hItem[ "nLineTotal" ] := nQty * nPrice

   AAdd( ::aItems, hItem )

   RETURN .T.

/**
 * Recalculates order subtotal, tax, and grand total
 * based on current line items and the given tax rate.
 * @param nTaxRate (N) -> Tax percentage to apply (0-100)
 * @return (N) -> Grand total after tax calculation
 * @since 2.0.0
 * @see AddItem
 * @example
 *   nTotal := oOrder:CalculateTotals( 12.0 )
 *   // Applies 12% tax to the subtotal
 */
METHOD CalculateTotals( nTaxRate ) CLASS TOrder
   LOCAL nI    := 0
   LOCAL hItem := NIL

   ::nSubtotal  := 0
   ::nTaxAmount := 0
   ::nTotal     := 0

   FOR nI := 1 TO Len( ::aItems )
      hItem := ::aItems[ nI ]
      ::nSubtotal += hItem[ "nLineTotal" ]
   NEXT

   ::nTaxAmount := ::nSubtotal * ( nTaxRate / 100 )
   ::nTotal     := ::nSubtotal + ::nTaxAmount

   RETURN ::nTotal

/**
 * Returns the current order status.
 * @return (C) -> Status string (PENDING, CONFIRMED, SHIPPED, CANCELLED)
 * @since 2.0.0
 * @see SetStatus
 */
METHOD GetStatus() CLASS TOrder
   RETURN ::cStatus

/**
 * Updates the order status and records the change timestamp.
 * Validates that the transition is allowed by business rules.
 * @param cNewStatus (C) -> New status value to set
 * @return (L) -> .T. if status was updated successfully
 * @since 2.0.0
 * @see GetStatus
 * @example
 *   oOrder:SetStatus( "CONFIRMED" )
 */
METHOD SetStatus( cNewStatus ) CLASS TOrder
   LOCAL aValidStatuses := { "PENDING", "CONFIRMED", "SHIPPED", "CANCELLED" }
   LOCAL nI := 0
   LOCAL lFound := .F.

   FOR nI := 1 TO Len( aValidStatuses )
      IF aValidStatuses[ nI ] == cNewStatus
         lFound := .T.
         EXIT
      ENDIF
   NEXT

   IF lFound
      ::cStatus    := cNewStatus
      ::dUpdatedAt := Date()
   ENDIF

   RETURN lFound

/**
 * Extended serialization including order fields and items.
 * @return (H) -> Complete hash with all order data
 * @since 2.0.0
 */
METHOD ToHash() CLASS TOrder
   LOCAL hOut   := ::Super:ToHash()
   LOCAL nI     := 0

   hOut[ "cCustomerId" ] := ::cCustomerId
   hOut[ "dOrderDate" ]  := ::dOrderDate
   hOut[ "cStatus" ]     := ::cStatus
   hOut[ "nSubtotal" ]   := ::nSubtotal
   hOut[ "nTaxAmount" ]  := ::nTaxAmount
   hOut[ "nTotal" ]      := ::nTotal
   hOut[ "nItemCount" ]  := Len( ::aItems )
   hOut[ "aItems" ]      := {}

   FOR nI := 1 TO Len( ::aItems )
      AAdd( hOut[ "aItems" ], HClone( ::aItems[ nI ] ) )
   NEXT

   RETURN hOut